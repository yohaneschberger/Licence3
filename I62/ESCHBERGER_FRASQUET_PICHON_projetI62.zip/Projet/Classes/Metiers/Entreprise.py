class Entreprise:
    '''
    Classe Entreprise
    '''
    def __inti__(self, nom, adresse, email, telephone):
        '''
        Constructeur de la classe Entreprise
        '''
        self.nom = nom
        self.adresse = adresse
        self.email = email
        self.telephone = telephone